(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_f1407974._.js",
  "static/chunks/src_app_login_page_tsx_219bf25b._.js"
],
    source: "dynamic"
});
