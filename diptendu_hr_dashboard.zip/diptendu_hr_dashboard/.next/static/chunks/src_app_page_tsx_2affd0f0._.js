(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_6d9c35e1._.js",
  "static/chunks/src_app_page_tsx_b025fed5._.js"
],
    source: "dynamic"
});
